export default class Nodo {
    constructor(data){
        this.data = data;
        this.enlace = null;
        this.before=null;
    }
}

