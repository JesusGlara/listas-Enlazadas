

import Nodo from "./nodo.js";

export default class ListaEnlazada{
    constructor(cabeza = null,cola = null){
        this.cabeza = cabeza;    
        this.cola=cola;            
    }

    /**
     * Este método insertar los nodos al inicio de la lista     * 
     * @param {*} data El parámetro data puede tomar cualquier valor
     */
    insertarInicio(data){
        let nuevo;
        nuevo = new Nodo(data);
        nuevo.enlace = this.cabeza;
        this.cabeza = nuevo;
    }

    /**
     * Este método inserta entre dos nodos en una lista enlazada simple
     * @param {*} valorInsertado Es el valor que se insertará en la lista
     * @param {*} buscar Indica detrás de qué nodo se debe insertar
     */
    insertarEntre(data, buscar){
      const  nuevo =new Nodo(data);
      let temp =this.cabeza;
        do{
          if(temp.enlace && temp.enlace.data===buscar){
           let tempo=temp.enlace;
            temp.enlace=nuevo;
            nuevo.enlace=tempo;
            break;
          }

        }while(temp!==null);
temp=temp.enlace;

    }

  eliminar(data){
        let temp= this.cabeza;
    
        // Si el nodo que se va a eliminar es el primero
        if (temp.data === this.cabeza) {
          this.cabeza = temp.enlace;
          
        }
    
        // Si el nodo que se va a eliminar está en el medio o el final
        while (temp.enlace !== null) {
          if (temp.enlace.data === data) {
            temp.enlace = temp.enlace.enlace;
            // Si el nodo que se va a eliminar es el último
            if (temp.enlace === null) {
              this.cola = temp;
            }
            
          }
        temp = temp.enlace;
        }

  }



 

    impresion(){
        let temp = this.cabeza;
        let valores = '';
        
        do{
            valores += temp.data + ' <=> ';
            temp = temp.enlace;
        }while(temp !== null);
        console.log(valores + 'null');
    }

  

}
