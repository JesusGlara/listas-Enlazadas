import ListaOrdenada from "./lista_Ordenada.js";
import Nodo from "./nodo.js";


export default class ListaDoble extends ListaOrdenada{
    
    constructor(){
        super(null);
    }

addToEnd(data){
    let nuevo;
    nuevo=new Nodo(data);
    if(this.cabeza!==null){
    this.cabeza=nuevo;
    this.cola=nuevo;
    }
    else{
    this.cola.enlace=nuevo;
    nuevo.before=this.cola;
    this.cola=nuevo;
    }}

    addToBeggin(data){
        let nuevo;
        nuevo=new Nodo(data);
        if(!this.cola){
        this.cabeza=nuevo;
        this.cola=nuevo;
        }
        else{
        this.cabeza.before=nuevo;
        nuevo.enlace=this.cabeza;
        this.cabeza=nuevo;
        }}

    delete(data){
        let copy = this.cabeza;
  while (copy) {
    if (copy.data === data) {
      if (copy === this.cabeza && copy === this.cola) {
        this.cabeza = null;
        this.cola = null;
      } else if (copy === this.cabeza) {
        this.cabeza = copy.enlace;
        this.cabeza.before = null;
      } else if (copy === this.cola) {
        this.cola = copy.before;
        this.cola.enlace = null;
      } else {
        copy.before.enlace = copy.enlace;
        copy.enlace.before = copy.before;
      }}
    copy = copy.enlace;
  } }

}